/*-------------------------------
EMBED VIDEO
-------------------------------*/

.videoembed_video {
  padding: 0; 
  margin:0 0 10px 10px;
  overflow: hidden;
  align: center;
}
.collapsable_box_content .thewire-post .videoembed_video {
  	margin: 10px 0 0 5px;
	position:relative;
    float:left; 
}
.collapsable_box_content .thewire-post .note_text{
	overflow:visible;
}