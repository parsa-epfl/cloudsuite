<?php //traducido por Emmanuel Lasso
$spanish = array(
	//Configuration form
	'embed_extender:width'				=> "Ancho del video",
	'embed_extender:widget_width'		=> "Ancho del video para widgets",
	'embed_extender:wire:show'			=> "Mostrar video en Actividad del sitio",
	'embed_extender:blog:show' 			=> "Mostrar video en entradas de blog",
	'embed_extender:comment:show' 		=> "Mostrar video en comentarios",
	'embed_extender:topicpost:show' 	=> "Mostrar video en publicaciones de grupos",
	'embed_extender:messageboard:show'	=> "Mostrar video en muro",
	'embed_extender:page:show' 			=> "Mostrar video en páginas",
	'embed_extender:bookmark:show' 		=> "Mostrar video en marcadores",
	'embed_extender:custom_provider' 	=> "Permitir proovedores personalizados",
	'embedvideo:novideo' 				=> 'No hay video especificado',
	'embedvideo:unrecognized' 			=> 'Sitio del video no reconocido',
	'embedvideo:parseerror' 			=> 'No podemos obtener %s desde la url especificada'
);
add_translation("es",$spanish);