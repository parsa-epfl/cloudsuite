This plugin is a extension of Cash�s Video Embed plugin. It allows video embedding in ELGG content. Just put the URL in blog posts, comments, messages, pages and the wire and video is displayed.

The plugin doesn't make changes in views and doesn't store or modify entities. It just parses the content, through views extending, and shows the video. If you disable the plugin, the video URL is displayed again.

The initial version supports Youtube, Vimeo and Metacafe. Others formats is on the way.